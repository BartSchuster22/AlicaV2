# G7 design candidate — signed standalone Cell

Status: **G7 IMPLEMENTATION AUTHORIZED; detailed packaging/restore contracts still pending freeze.**
Source baseline: `79702d16d41153ea3ad4518be7b04eb8a45b43c1`.
G6 is [accepted](../gates/G6-OWNER-ACCEPTANCE.md). The owner subsequently requested
G7 implementation and approved scoped OS environments and online signing custody.
Operator bootstrap tooling now has component tests; no G7 acceptance is claimed.

## Authority and unchanged contracts

Historical preparation began under “Keep formal G6 acceptance pending; prepare
Phase 7’s design and prerequisites only.” Later owner instructions accepted G6,
requested G7 implementation, approved scoped Alicav1/DSH2 environment setup, and
replaced offline key custody with online software custody on ElioHermes1. These
authorizations do not waive packaging/restore contract review, host protections,
exact-candidate qualification or owner release acceptance.

The governing sources are [the phase plan](../planning/ALICA_V2_Assessment_and_Step1_Building_Plan.md),
[bundle](../../specs/ALICA-BUNDLE-v1.md), [profile](../../specs/ALICA-PROFILE-v1.md),
[trust](../../specs/ALICA-TRUST-POLICY-v1.md), and especially the superseding
[G1 completion clauses](../../specs/ALICA-NORMATIVE-BASELINE-v1.md).
Historical status headings in those documents are not rewritten here.
[ADR-009](../adr/ADR-009.md) requires an exact durable journal/restore schema before
packaging implementation. This candidate describes the proposed model; that
schema and its crash-transition vectors remain an explicit entry blocker.

## Scope and deployment boundary

Package the existing Kernel, public contracts/SDK runtime dependencies, native IPC
launcher/bridge and synthetic providers/consumer only. Keep packaging and Cell
administration outside Kernel. No V1 binaries/data, Hermes, MemoryV4, Unify,
Docker, database, licensing migration or central runtime service is required.

Proposed first target: the existing qualified Ubuntu 24.04 x86_64 platform and
pinned Node/native build inputs. Compatibility is checked on the actual acceptance
hosts, including ABI, native libraries and required confinement facilities.
Unsupported confinement fails closed; no fallback to an unsandboxed worker.
Other architectures/OSs require separate qualification, not inferred portability.

The offline claim starts with a prepared OS and a separately trusted bootstrap
verifier. It does NOT cover network-free provisioning of an empty machine.
OS/kernel/shared-library/clock prerequisites must be inventoried with exact host
versions. Application runtime, dependencies, schemas and verification data are
included; design-only Python/TypeScript tooling must not silently become runtime
requirements. No install-time npm/pip/apt or lifecycle-script fetch is allowed.

## Trust before running the bundled runtime

A runtime inside an unverified archive cannot authenticate its own distribution.
Proposed bootstrap: an operator-provisioned verifier toolkit whose complete bytes
are authenticated out of band, separately from the candidate archive. It can use
a separately pinned Node and closed verifier dependency set. Its installation,
trusted digest/root ceremony and offline availability need owner approval and
independent testing; a checksum copied from the untrusted archive is insufficient.

Root, publisher/release and repository SSH/API credentials have distinct roles.
Use the existing Ed25519 signature domains and canonicalization unchanged.
The owner has generated encrypted production-intent keys through the separately
invoked custody setup; their encrypted off-server archive was checksum-verified.
See [custody and bootstrap status](CUSTODY.md).
Development/test keys are visibly test-only and cannot qualify a production
candidate. Online custody and manual signer access are approved. Actual signed bootstrap,
revocation publication, safe metadata renewal and application recovery remain
required before producing an accepted signed candidate.

Bootstrap trust-policy and revocation material is authenticated under the
operator-pinned root, never trusted merely because it accompanies a bundle.
Before activation AND delivery, enforce signed expiry/freshness and persisted
monotonic version/time high-water marks. Backward clock movement invalidates
freshness pending explicit operator recovery. Offline mode never suppresses
revocation or time checks. Rotation retains dual-root authorization and the
new-root signature on the next policy. Lost-root recovery requires separately
custodied recovery material or explicit new-Cell initialization, not a reset flag.

## Artifact graph and reproducibility

1. Build from a recorded source revision with locked compiler/dependency inputs.
2. Construct package indexes binding raw code, manifests and descriptor bytes.
   Package identity is the canonical index digest, not a hash of a tar file.
3. Compose a profile of exact synthetic plugin versions/package digests and
   logical scopes. Produce the deterministic resolution lock, including immutable
   policy digest and exact provider/contract bindings. No runtime generations,
   local paths, Cell identity, secrets or trust overrides in portable bytes.
4. Inventory runtime, packages, profile/lock, schemas, verification material,
   SBOM/provenance and documentation. Bundle inventory digests bind RAW file
   bytes, whereas profile/policy/lock/index identities bind canonical JSON.
5. Sign the canonical bundle manifest in the existing bundle domain; the detached
   signature is outside its own signed inventory. The package index excludes
   higher-level bundle/profile/lock/signature data to prevent digest cycles.

The existing bundle schema is closed. Mapping the lock, policy, revocation and
signature-envelope files to its existing artifact kinds and defining allowed
metadata paths is a review item: do not add fields/kinds silently. Both hosts
receive identical profile, lock and accepted policy bytes; host identity, paths,
secret values and runtime instance generations are deliberately separate.

SBOM coverage includes shipped Node/runtime components, transitive production
JavaScript dependencies, native bridge/launcher dependencies and licenses.
Declare OS-provided dependencies separately. A dependency identity list with
unknown transitive coverage fails the coverage criterion. Provenance distinguishes
source compilation from repackaged upstream runtime binaries and records builder,
source, inputs, outputs and toolchain. A signed statement is not proof of an
unobserved build. Build reproducibility must be measured, not presumed.

## Extraction and local state — proposed design

Use a single-writer Cell-administration lock and an owner-only state root.
Proposed layout: immutable content-addressed releases; private staging; a durable
accepted-release record; separate trust high-water state, identity and secrets;
and a bounded transaction journal. Do not serialize live handles/scopes/grants as
reusable authority. Recreate fresh runtime instances and operator-authorized grants.

Preflight a bounded manifest and the entire archive structure. Proposed supported
archive subset: regular files only; reconstruct parent directories locally.
Reject symlinks/hardlinks, traversal, absolute/duplicate names, devices, sockets,
unsupported archive metadata, undeclared files, length/digest mismatch and
trailing payload. Use no-follow/descriptor-relative creation to resist filesystem
races. Schema permits at most 4096 artifacts; additionally approve numerical
archive size, expanded size, per-file size, disk reserve and timeout limits before
implementation. Tests include decompression and small-file exhaustion. Staging
must be on the same filesystem as publication, privately owned and non-executable
until validation completes. No archive-supplied hooks execute.

Proposed journal states: STAGING -> VERIFIED -> ACTIVATING -> COMMITTED;
failed transactions enter RECOVERING then ABORTED or NEEDS_OPERATOR. Each record
binds transaction ID, intended/prior release and profile/lock digests, monotonic
sequence and outcome. Exact closed schemas, append/replace rules, locking,
checksums, fsync ordering and crash vectors require review before implementation.

Verify every artifact and trust condition before starting candidate code. Stop
admission/quiesce the old runtime with bounded cleanup; never falsely report reap.
Start the candidate with fresh instances and run synthetic readiness/call checks.
Publish the accepted-release record only after success using atomic replacement
and required file/directory durability barriers. A crash before publication keeps
the prior accepted selection; startup reconciles incomplete transactions before
admitting calls. Ambiguous/corrupt journals fail closed instead of guessing.
Installation atomicity covers accepted local configuration, NOT rollback of
arbitrary provider side effects or replay of interrupted calls.

Exact reinstall is a no-op only when accepted digests, bytes and current trust
still validate. It must not rewrite identity, secrets or trust high-water marks.
Failure recovery may reactivate the last-known-good release only if it remains
trusted NOW. Rolling back a release must never roll back revocation/policy versions,
clock high-water marks or revive old handles. Cleanup/reap uncertainty blocks
replacement, not a successful status report.

## Proposed operator control boundary

A long-lived, trusted Cell supervisor owns the Kernel; a CLI invocation is not a
provider and must not acquire administrative authority through a public SDK call.
Proposed administration uses a private local channel beneath the owner-only Cell
root, authenticated OS peer ownership and a verified supervisor incarnation.
There is no remote TCP administration endpoint in this profile. Define closed
request/response schemas, size/time limits, lock/process ownership and stale-socket
recovery before implementation. Never reuse a provider work endpoint as an admin
channel. Same-UID operator compromise remains outside plugin confinement guarantees.

Grant creation follows separately authenticated operator authorization inputs,
intersected with signed manifests and trust policy. Exact closed authorization-input
formats are a review prerequisite; profile permission requests do not mint grants.
On restart, resolve the approved intent into grants for fresh instance and exact
scope generations. Do not deserialize previous runtime grant IDs as authority or
allow candidate artifacts to supply operator authorization. This adds no public
SDK method or frozen schema field.

## Proposed CLI and backup boundary

Working CLI name: `alica-cell`, distinct from contract tooling `alicac`; owner
review required. Proposed verbs: plan/install/status/verify/stop/start/upgrade/
recover/backup/restore. These are NOT available commands yet. Read-only planning
must not create an identity or grants. Mutating operations require explicit Cell
root, exclusive ownership and checked preconditions, and return structured,
redacted outcome/transaction identifiers. No automatic service installation.

Backups must bind the accepted inventory, identity and required durable state.
Secret/identity recovery material is separately custodied and encrypted using a
reviewed standard tool/library; format, dependency inclusion, custody and restore
schema remain open review items. No hand-written crypto or token in archives/logs.
A clean restore revalidates trust and freshness against current approved metadata;
a stale backup cannot lower high-water state. Test wrong keys, tampering, missing
material and stale revocation. Source environment stays intact until independent
restore and synthetic calls succeed.

## Preparation outputs and entry control

See [prerequisites](PREREQUISITES.md), [acceptance matrix](ACCEPTANCE-MATRIX.md)
and [G7 gate](../gates/G7.md). Approving this prose later does not by itself approve
unknown host access, signing custody or an incomplete journal/restore schema.
