// Test-only boundary observation/fault injection, loaded only in maintenance Node.
import { createRequire, syncBuiltinESMExports } from 'node:module';
import fs from 'node:fs';
import { join } from 'node:path';
import { rawDigest } from '@alica/acap-contracts';
import { CellPreparation } from '../../tools/g7-cell.mjs';
const ownedReinstall = CellPreparation.prototype.ownedReinstall;
CellPreparation.prototype.ownedReinstall = async function(...args) {
  try { return await ownedReinstall.apply(this,args); }
  catch(e) { console.error('TEST-ONLY',e.stack); throw e; }
};
const native = createRequire(import.meta.url)('../../native/g7/build/ownership.node');
const directory = process.env.G7_CROSS_DIRECTORY;
if (directory && process.argv[1]?.endsWith('g7-owned-cli.mjs')) {
  const root = process.argv[3], mode = process.env.G7_CROSS_MODE;
  const snapshot = () => Object.fromEntries(fs.readdirSync(root, {recursive: true}).sort().flatMap(p => {
    const s = fs.lstatSync(join(root,p));
    return s.isFile() ? [[p,{ino:s.ino,mode:s.mode,mtimeMs:s.mtimeMs,digest:rawDigest(fs.readFileSync(join(root,p)))}]] : [];
  }));
  const record = (event, data={}) => fs.appendFileSync(join(directory,'events.jsonl'), JSON.stringify({event,pid:process.pid,...data})+'\n');
  const receive = native.packetReceive;
  native.packetReceive = (fd,pid) => {
    const packet = receive(fd,pid);
    if (packet) record('packet', {child:pid,packet:packet.toString()});
    if (packet?.subarray(0,6).toString() === 'CLEAN ') {
      fs.writeFileSync(join(directory,'before.json'), JSON.stringify(snapshot()));
      record('clean-boundary');
      if (mode === 'pause-clean') {
        const f = fs.openSync(join(directory,'pause.fifo'),'r'); fs.readSync(f,Buffer.alloc(1),0,1,null); fs.closeSync(f);
      }
      if (mode === 'kill-coordinator') process.kill(pid,'SIGKILL');
      if (mode === 'forged-clean') return Buffer.from('CLEAN {"status":"STOPPED","sequence":2,"acceptedDigest":"sha256:'+'0'.repeat(64)+'"}');
    }
    return packet;
  };
  const send = native.packetSend;
  native.packetSend = (fd,packet) => {
    record('send',{packet:packet.toString()});
    if (packet.toString() === 'DONE') fs.writeFileSync(join(directory,'after.json'), JSON.stringify(snapshot()));
    return send(fd,packet);
  };
  const read = fs.readFileSync;
  fs.readFileSync = function(path,...args) {
    if (mode === 'block-maintenance' && String(path).endsWith('/kernel.json') && fs.existsSync(join(directory,'before.json'))) {
      record('blocked-maintenance');
      const f = fs.openSync(join(directory,'pause.fifo'),'r'); fs.readSync(f,Buffer.alloc(1),0,1,null);
    }
    return read.call(this,path,...args);
  };
  syncBuiltinESMExports();
}
