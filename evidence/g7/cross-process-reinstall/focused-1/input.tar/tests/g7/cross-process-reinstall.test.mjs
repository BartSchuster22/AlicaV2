import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync,mkdirSync,writeFileSync,readFileSync,readdirSync,lstatSync,existsSync,rmSync,cpSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join,resolve,dirname } from 'node:path';
import { spawn,spawnSync } from 'node:child_process';
import { once } from 'node:events';
import { setTimeout as delay } from 'node:timers/promises';
import { canonical } from '@alica/acap-contracts';
import { CellPreparation } from '../../tools/g7-cell.mjs';
import { cellFixture } from './cell-fixture.mjs';
import { signature } from '../../tools/g3-fixtures.mjs';
async function wait(fn,ms=20000) {
 const end=performance.now()+ms;
 while(performance.now()<end) { const v=fn(); if(v) return v; await delay(10); }
 throw new Error('condition timed out');
}
async function setup(t,mode='none') {
 const dir=mkdtempSync(join(tmpdir(),'g7-cross-')), f=await cellFixture(dir), root=join(dir,'cell');
 f.trust.revocation.version=2;
 f.trust.revocationSignature=signature(f.trust.revocation,'ALICA-REVOCATION-v1',f.root);
 mkdirSync(root,{mode:0o700});
 const cell=new CellPreparation(root); await cell.initialize(f.trust,f.floor); cell.close();
 const input=join(dir,'input.json');
 const writeInput=()=>writeFileSync(input,canonical({archive:f.archive,trust:f.trust,authorization:f.authorization}),{mode:0o600});
 writeInput();
 assert.equal(spawnSync('mkfifo',[join(dir,'pause.fifo')]).status,0);
 const child=spawn(process.execPath,['--experimental-vm-modules','tools/g7-owned-cli.mjs','exact-reinstall',root,input],{
 detached:true,stdio:['ignore','pipe','pipe'],env:{...process.env,G7_CROSS_DIRECTORY:dir,G7_CROSS_MODE:mode,NODE_OPTIONS:'--import='+resolve('tests/g7/cross-process-block.mjs')}
 });
 let output='',errors=''; child.stdout.on('data',b=>output+=b); child.stderr.on('data',b=>errors+=b);
 t.after(async()=>{
  try{process.kill(-child.pid,'SIGKILL');}catch(e){if(e.code!=='ESRCH')throw e;}
  if(child.exitCode===null&&child.signalCode===null)await once(child,'exit');
  if(process.env.G7_CROSS_EVIDENCE){
   const target=join(process.env.G7_CROSS_EVIDENCE,dir.split('/').at(-1)); mkdirSync(target,{recursive:true});
   writeFileSync(join(target,'stdout.log'),output);writeFileSync(join(target,'stderr.log'),errors);
   for(const p of readdirSync(dir,{recursive:true}))if(lstatSync(join(dir,p)).isFile()){
    const dest=join(target,'originals',p);mkdirSync(dirname(dest),{recursive:true});cpSync(join(dir,p),dest);
   }
  }
  rmSync(dir,{recursive:true,force:true});
 });
 return {...f,dir,rootPath:root,input,writeInput,child,output:()=>output,errors:()=>errors};
}
async function resume(f){const p=spawn('python3',['-c','import os,sys;f=os.open(sys.argv[1],os.O_WRONLY);os.write(f,b"x");os.close(f)',join(f.dir,'pause.fifo')]); await once(p,'exit');}
function excluded(f){const p=spawnSync(process.execPath,['--input-type=module','-e',"import {CellPreparation} from './tools/g7-cell.mjs';new CellPreparation(process.argv[1]);",f.rootPath],{encoding:'utf8'});assert.notEqual(p.status,0);}
test('cross-process exact reinstall: actual original Cell/Kernel bytes and inodes preserved, fence retained', {timeout:30000}, async t=>{
 const f=await setup(t);
 await wait(()=>f.child.exitCode!==null||f.child.signalCode!==null);
 assert.equal(f.child.exitCode,0,f.errors());
 const result=JSON.parse(f.output()); assert.equal(result.operation,'exact-reinstall');assert.equal(result.status,'STOPPED');assert.equal(result.fence,'RETAINED');
 assert.deepEqual(JSON.parse(readFileSync(join(f.dir,'after.json'))),JSON.parse(readFileSync(join(f.dir,'before.json'))));
 const events=readFileSync(join(f.dir,'events.jsonl'),'utf8').trim().split('\n').map(JSON.parse);
 assert(events.some(e=>e.event==='packet'&&e.packet.startsWith('CLEAN ')&&e.child!==e.pid));
 assert(events.some(e=>e.event==='send'&&e.packet==='CLEANUP'));
 excluded(f);
 const retry=spawnSync(process.execPath,['tools/g7-owned-cli.mjs','exact-reinstall',f.rootPath,f.input],{encoding:'utf8',timeout:5000});
 assert.equal(retry.status,1);
});
for(const kind of ['same-version-equivocation','revoked-bundle','authorization','archive','forged-clean','kill-coordinator'])test('cross-process rejects '+kind,{timeout:30000},async t=>{
 const f=await setup(t,['forged-clean','kill-coordinator'].includes(kind)?kind:'pause-clean');
 await wait(()=>existsSync(join(f.dir,'before.json')));
 excluded(f);
 if(kind==='same-version-equivocation'){f.trust.revocation.expiresAtMs++;f.trust.revocationSignature=signature(f.trust.revocation,'ALICA-REVOCATION-v1',f.root);f.writeInput();}
 if(kind==='revoked-bundle'){f.trust.revocation.version++;f.trust.revocation.revokedArtifactDigests.push(JSON.parse(readFileSync(join(f.rootPath,'accepted.json'))).release.bundleDigest);f.trust.revocationSignature=signature(f.trust.revocation,'ALICA-REVOCATION-v1',f.root);f.writeInput();}
 if(kind==='authorization'){f.authorization.capabilities[0].lifetimeMs--;f.writeInput();}
 if(kind==='archive'){const b=readFileSync(f.archive);b[b.length-1]=1;writeFileSync(f.archive,b);}
 if(!['forged-clean','kill-coordinator'].includes(kind))await resume(f);
 await wait(()=>f.child.signalCode!==null||f.errors().includes('NEEDS_OPERATOR'));
 assert(!f.output().includes('"status":"STOPPED"'));
 assert(!existsSync(join(f.dir,'after.json')));
 excluded(f);
});
