import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync,mkdirSync,writeFileSync,readFileSync,readdirSync,lstatSync,existsSync,rmSync,cpSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join,resolve,dirname } from 'node:path';
import { spawn,spawnSync } from 'node:child_process';
import { once } from 'node:events';
import { setTimeout as delay } from 'node:timers/promises';
import { canonical, digest, rawDigest } from '@alica/acap-contracts';
import { assembleRelease, artifactKind } from '../../tools/g7-release.mjs';
import { CellPreparation } from '../../tools/g7-cell.mjs';
import { cellFixture } from './cell-fixture.mjs';
import { signature } from '../../tools/g3-fixtures.mjs';
import { validateJournal, validateHistory } from '../../tools/g7-cell.mjs';
async function wait(fn,ms=20000) {
 const end=performance.now()+ms;
 while(performance.now()<end) { const v=fn(); if(v) return v; await delay(10); }
 throw new Error('condition timed out');
}
async function setup(t,mode='none',upgrade=false) {
 const dir=mkdtempSync(join(tmpdir(),'g7-cross-')), f=await cellFixture(dir), root=join(dir,'cell');
 f.trust.revocation.version=2;
 f.trust.revocationSignature=signature(f.trust.revocation,'ALICA-REVOCATION-v1',f.root);
 mkdirSync(root,{mode:0o700});
 const cell=new CellPreparation(root); await cell.initialize(f.trust,f.floor); cell.close();
 const input=join(dir,'input.json');
 const writeInput=()=>writeFileSync(input,canonical({archive:f.archive,trust:f.trust,authorization:f.authorization}),{mode:0o600});
 writeInput();
 let target;
 if(upgrade){
  // New target archive, not replacement of the original accepted archive/files.
  const files=new Map(f.files);files.set('docs/fixture.txt',Buffer.from('Second immutable release; original retained.'));
  const bundle=structuredClone(f.bundle);bundle.artifacts=[...files].map(([path,b])=>({path,bytes:b.length,digest:rawDigest(b),kind:artifactKind(path)}));
  const archive=join(dir,'target.tar');assembleRelease(archive,Buffer.from(canonical(bundle)),Buffer.from(canonical(signature(bundle,'ALICA-BUNDLE-v1',f.publisher))),files);
  target=join(dir,'target.json');writeFileSync(target,canonical({archive,trust:f.trust,authorization:f.authorization}),{mode:0o600});
 }
 assert.equal(spawnSync('mkfifo',[join(dir,'pause.fifo')]).status,0);
 const child=spawn(process.execPath,['--experimental-vm-modules','tools/g7-owned-cli.mjs',upgrade?'upgrade':'exact-reinstall',root,input,...(upgrade?[target]:[])],{
 detached:true,stdio:['ignore','pipe','pipe'],env:{...process.env,G7_CROSS_DIRECTORY:dir,G7_CROSS_MODE:mode,NODE_OPTIONS:'--import='+resolve('tests/g7/cross-process-block.mjs')}
 });
 let output='',errors=''; child.stdout.on('data',b=>output+=b); child.stderr.on('data',b=>errors+=b);
 t.after(async()=>{
  try{process.kill(-child.pid,'SIGKILL');}catch(e){if(e.code!=='ESRCH')throw e;}
  if(child.exitCode===null&&child.signalCode===null)await once(child,'exit');
  if(process.env.G7_CROSS_EVIDENCE){
   const target=join(process.env.G7_CROSS_EVIDENCE,dir.split('/').at(-1)); mkdirSync(target,{recursive:true});
   writeFileSync(join(target,'stdout.log'),output);writeFileSync(join(target,'stderr.log'),errors);
   for(const p of readdirSync(dir,{recursive:true}))if(lstatSync(join(dir,p)).isFile()){
    const dest=join(target,'originals',p);mkdirSync(dirname(dest),{recursive:true});cpSync(join(dir,p),dest);
   }
  }
  rmSync(dir,{recursive:true,force:true});
 });
 return {...f,dir,rootPath:root,input,writeInput,child,output:()=>output,errors:()=>errors};
}
async function resume(f){const p=spawn('python3',['-c','import os,sys;f=os.open(sys.argv[1],os.O_WRONLY);os.write(f,b"x");os.close(f)',join(f.dir,'pause.fifo')]); await once(p,'exit');}
function excluded(f){const p=spawnSync(process.execPath,['--input-type=module','-e',"import {CellPreparation} from './tools/g7-cell.mjs';new CellPreparation(process.argv[1]);",f.rootPath],{encoding:'utf8'});assert.notEqual(p.status,0);}
test('cross-process exact reinstall: actual original Cell/Kernel bytes and inodes preserved, fence retained', {timeout:30000}, async t=>{
 const f=await setup(t);
 await wait(()=>f.child.exitCode!==null||f.child.signalCode!==null);
 assert.equal(f.child.exitCode,0,f.errors());
 const result=JSON.parse(f.output()); assert.equal(result.operation,'exact-reinstall');assert.equal(result.status,'STOPPED');assert.equal(result.fence,'RETAINED');
 assert.deepEqual(JSON.parse(readFileSync(join(f.dir,'after.json'))),JSON.parse(readFileSync(join(f.dir,'before.json'))));
 const events=readFileSync(join(f.dir,'events.jsonl'),'utf8').trim().split('\n').map(JSON.parse);
 assert(events.some(e=>e.event==='packet'&&e.packet.startsWith('CLEAN ')&&e.child!==e.pid));
 assert(events.some(e=>e.event==='send'&&e.packet==='CLEANUP'));
 excluded(f);
 const retry=spawnSync(process.execPath,['tools/g7-owned-cli.mjs','exact-reinstall',f.rootPath,f.input],{encoding:'utf8',timeout:5000});
 assert.equal(retry.status,1);
});
for(const kind of ['same-version-equivocation','revoked-bundle','authorization','archive','forged-clean','kill-coordinator'])test('cross-process rejects '+kind,{timeout:30000},async t=>{
 const f=await setup(t,['forged-clean','kill-coordinator'].includes(kind)?kind:'pause-clean');
 await wait(()=>existsSync(join(f.dir,'before.json')));
 excluded(f);
 if(kind==='same-version-equivocation'){f.trust.revocation.expiresAtMs++;f.trust.revocationSignature=signature(f.trust.revocation,'ALICA-REVOCATION-v1',f.root);f.writeInput();}
 if(kind==='revoked-bundle'){f.trust.revocation.version++;f.trust.revocation.revokedArtifactDigests.push(JSON.parse(readFileSync(join(f.rootPath,'accepted.json'))).release.bundleDigest);f.trust.revocationSignature=signature(f.trust.revocation,'ALICA-REVOCATION-v1',f.root);f.writeInput();}
 if(kind==='authorization'){f.authorization.capabilities[0].lifetimeMs--;f.writeInput();}
 if(kind==='archive'){const b=readFileSync(f.archive);b[b.length-1]=1;writeFileSync(f.archive,b);}
 if(!['forged-clean','kill-coordinator'].includes(kind))await resume(f);
 await wait(()=>f.child.signalCode!==null||f.errors().includes('NEEDS_OPERATOR'));
 assert(!f.output().includes('"status":"STOPPED"'));
 assert(!existsSync(join(f.dir,'after.json')));
 excluded(f);
});

function journals(f){return readdirSync(join(f.rootPath,'transactions')).map(tx=>{
 const rows=readdirSync(join(f.rootPath,'transactions',tx)).sort().map(n=>JSON.parse(readFileSync(join(f.rootPath,'transactions',tx,n))));
 return {rows,last:validateJournal(rows)};
});}
test('owned upgrade commits a distinct immutable target with original prior history and actual new IPC readiness', {timeout:30000},async t=>{
 const f=await setup(t,'none',true);
 await wait(()=>f.child.exitCode!==null||f.child.signalCode!==null);
 assert.equal(f.child.exitCode,0,f.errors());
 const result=JSON.parse(f.output());assert.equal(result.operation,'upgrade');assert.equal(result.status,'STOPPED');assert.equal(result.accepted.sequence,2);
 const js=journals(f).sort((a,b)=>a.last.targetRevision-b.last.targetRevision);
 assert.equal(js.length,2);assert.deepEqual(js.map(j=>j.last.state),['COMMITTED','COMMITTED']);
 assert.equal(js[1].last.operation,'upgrade');assert.equal(js[1].last.priorRevision,1);assert.deepEqual(js[1].last.prior,js[0].last.target);
 assert.notEqual(js[1].last.target.bundleDigest,js[0].last.target.bundleDigest);
 assert.equal(js[0].last.target.bundleDigest,digest(f.bundle));
 const before=JSON.parse(readFileSync(join(f.dir,'before.json'))),after=JSON.parse(readFileSync(join(f.dir,'after.json')));
 for(const [p,b] of Object.entries(before))if(p==='identity.json'||p.startsWith('releases/')||p.startsWith('transactions/'))assert.deepEqual(after[p],b,p);
 const floor=JSON.parse(readFileSync(join(f.rootPath,'floor.json')));
 validateHistory([...js].reverse(),result.accepted,result.accepted.cellId,floor);
 for(const mutation of ['missing-prior','fork','wrong-prior','old-selection','backward-trust']){
  const bad=structuredClone(js),selected=structuredClone(result.accepted);
  if(mutation==='missing-prior')bad.shift();
  if(mutation==='fork')bad.push(structuredClone(bad[1]));
  if(mutation==='wrong-prior')bad[1].last.prior=bad[1].last.target;
  if(mutation==='old-selection'){selected.sequence=1;selected.transactionId=bad[0].last.transactionId;selected.release=bad[0].last.target;}
  if(mutation==='backward-trust')bad[1].rows[0].record.trustFloor.lastWallMs=0;
  assert.throws(()=>validateHistory(bad,selected,result.accepted.cellId,floor),mutation);
 }
 excluded(f);
});
for(const mode of ['crash-before-accepted','crash-after-accepted','crash-after-accepted-fsync','uncertain-rename','uncertain-directory-fsync'])test('owned upgrade conservative publication: '+mode,{timeout:30000},async t=>{
 const f=await setup(t,mode,true);
 await wait(()=>f.child.signalCode!==null||f.errors().includes('NEEDS_OPERATOR'));
 assert(!f.output().includes('"status":"STOPPED"'));excluded(f);
 const accepted=JSON.parse(readFileSync(join(f.rootPath,'accepted.json')));
 assert.equal(accepted.sequence,mode==='crash-before-accepted'?1:2);
 const js=journals(f),upgrade=js.find(j=>j.last.operation==='upgrade');
 assert.equal(upgrade.last.state,'ACTIVATING');
 assert.equal(js.find(j=>j.last.operation==='install').last.state,'COMMITTED');
 // No automatic rollback, terminal fabrication or replay after uncertain commit.
 const retry=spawnSync(process.execPath,['tools/g7-owned-cli.mjs','upgrade',f.rootPath,f.input,join(f.dir,'target.json')],{encoding:'utf8',timeout:5000});assert.equal(retry.status,1);
 assert.deepEqual(JSON.parse(readFileSync(join(f.rootPath,'accepted.json'))),accepted);
});
for(const [mode,budget] of [['block-cleanup',30000],['block-maintenance',300000]])test('independent watchdog contains synchronous '+mode+' at real deadline',{timeout:budget+20000},async t=>{
 const f=await setup(t,mode);
 await wait(()=>existsSync(join(f.dir,'events.jsonl'))&&readFileSync(join(f.dir,'events.jsonl'),'utf8').includes('blocked-'));
 const start=performance.now();excluded(f);
 await wait(()=>f.child.signalCode!==null,budget+5000);
 const elapsed=performance.now()-start;
 assert.equal(f.child.signalCode,'SIGKILL');assert(elapsed>=budget-1000&&elapsed<budget+5000,String(elapsed));
 assert(!f.output().includes('"status":"STOPPED"'));excluded(f);
});

