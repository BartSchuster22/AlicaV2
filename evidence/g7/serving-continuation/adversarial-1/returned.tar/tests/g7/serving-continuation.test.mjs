import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, readdirSync, lstatSync, existsSync, rmSync, cpSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve, dirname } from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { once } from 'node:events';
import { setTimeout as delay } from 'node:timers/promises';
import { canonical, digest, rawDigest } from '@alica/acap-contracts';
import { CellPreparation } from '../../tools/g7-cell.mjs';
import { adminRequest } from '../../tools/g7-admin.mjs';
import { cellFixture } from './cell-fixture.mjs';
import { upgradeTarget } from './cross-process-target.mjs';
import { signature } from '../../tools/g3-fixtures.mjs';
async function wait(fn, ms = 20000) {
  const end = performance.now() + ms;
  while (performance.now() < end) { const result = fn(); if (result) return result; await delay(10); }
  throw new Error('condition timed out');
}
function inventory(root) {
  return Object.fromEntries(readdirSync(root, { recursive: true }).sort().flatMap(p => {
    const s = lstatSync(join(root, p));
    return s.isFile() ? [[p, { ino: s.ino, mode: s.mode, digest: rawDigest(readFileSync(join(root, p))) }]] : [];
  }));
}
async function setup(t, mode = 'none', cli) {
  const dir = mkdtempSync(join(tmpdir(), 'g7-serve-'));
  const f = await cellFixture(dir), rootPath = join(dir, 'cell');
  cpSync(f.archive, join(dir, 'accepted-original.tar'));
  f.trust.revocation.version = 2;
  f.trust.revocationSignature = signature(f.trust.revocation, 'ALICA-REVOCATION-v1', f.root);
  mkdirSync(rootPath, { mode: 0o700 });
  const cell = new CellPreparation(rootPath);
  await cell.initialize(f.trust, f.floor); cell.close();
  const input = join(dir, 'input.json');
  const writeInput = () => writeFileSync(input, canonical({ archive: f.archive, trust: f.trust, authorization: f.authorization }), { mode: 0o600 });
  writeInput();
  const target = await upgradeTarget(dir, f, mode);
  assert.equal(spawnSync('mkfifo', [join(dir, 'pause.fifo')]).status, 0);
  const child = spawn(process.execPath, ['--experimental-vm-modules',
    ...(cli ? ['tools/g7-owned-cli.mjs', cli, rootPath, input, ...(cli === 'cycle' ? [target, target] : [])] : ['tests/g7/serving-driver.mjs', rootPath, input, target])], {
    detached: true, stdio: ['pipe', 'pipe', 'pipe'], env: { ...process.env, G7_SERVING_DIR: dir, G7_SERVING_MODE: mode,
      NODE_OPTIONS: '--import=' + resolve('tests/g7/serving-faults.mjs') },
  });
  let output = '', errors = '';
  child.stdout.on('data', b => output += b); child.stderr.on('data', b => errors += b);
  t.after(async () => {
    try { process.kill(-child.pid, 'SIGKILL'); } catch (e) { if (e.code !== 'ESRCH') throw e; }
    if (child.exitCode === null && child.signalCode === null) await once(child, 'exit');
    if (process.env.G7_SERVING_EVIDENCE) {
      const dest = join(process.env.G7_SERVING_EVIDENCE, dir.split('/').at(-1)); mkdirSync(dest, { recursive: true });
      writeFileSync(join(dest, 'stdout.log'), output); writeFileSync(join(dest, 'stderr.log'), errors);
      for (const p of readdirSync(dir, { recursive: true })) if (lstatSync(join(dir, p)).isFile()) {
        mkdirSync(dirname(join(dest, 'originals', p)), { recursive: true }); cpSync(join(dir, p), join(dest, 'originals', p));
      }
    }
    rmSync(dir, { recursive: true, force: true });
  });
  const rows = () => output.trim().split('\n').filter(Boolean).map(JSON.parse);
  const event = async (name, count = 1) => wait(() => rows().filter(r => r.event === name)[count - 1]);
  const command = async (name, count = 1) => { child.stdin.write(name + '\n'); return event(name, count); };
  return { ...f, dir, rootPath, input, target, child, writeInput, rows, event, command, output: () => output, errors: () => errors };
}
function selection(f) { return JSON.parse(readFileSync(join(f.rootPath, 'accepted.json'))); }
async function admin(f, version, operation, extra = {}) {
  const a = selection(f), incarnation = JSON.parse(readFileSync(join(f.rootPath, 'supervision/incarnation.json'))).incarnation;
  const request = { schemaVersion: 'alica.cell-admin-request/v' + version, requestId: 'serving-request', incarnation,
    expectedSequence: a.sequence, operation, ...extra };
  const result = await adminRequest(f.rootPath, version, request);
  return { request, result, accepted: a };
}
async function exactAdmin(f, version, operation, status) {
  const { request, result, accepted } = await admin(f, version, operation);
  assert.deepEqual(JSON.parse(canonical(result)), { schemaVersion: 'alica.cell-admin-response/v' + version,
    requestId: request.requestId, incarnation: request.incarnation, status, code: 'OK', sequence: accepted.sequence, acceptedDigest: digest(accepted) });
}
function excluded(f) {
  const p = spawnSync(process.execPath, ['--experimental-vm-modules', '--input-type=module', '-e',
    "import {CellPreparation} from './tools/g7-cell.mjs';new CellPreparation(process.argv[1]);", f.rootPath], { encoding: 'utf8' });
  assert.equal(p.status, 1); assert.match(p.stderr, /code: '(CONFLICT|FAILED_PRECONDITION)'/);
}
test('continuous original Cell: serve, admin stop/start v1/v2, exact reinstall, real upgrade, repeated serving and maintenance', { timeout: 60000 }, async t => {
  const f = await setup(t); const first = await f.event('begin');
  const original = inventory(f.rootPath), fence = lstatSync(join(f.rootPath, 'supervision')).ino;
  await f.command('serve');
  await exactAdmin(f, 1, 'status', 'RUNNING'); await exactAdmin(f, 2, 'stop', 'STOPPED');
  await exactAdmin(f, 1, 'start', 'RUNNING'); await exactAdmin(f, 2, 'status', 'RUNNING'); excluded(f);
  const stop = await f.command('concurrent'); assert.equal(stop.result.runtime, 'STOPPED');
  assert.deepEqual(stop.result.accepted, first.result.accepted);
  for (const [p, v] of Object.entries(original)) if (!['kernel.json', 'floor.json'].includes(p) && !p.startsWith('supervision/')) assert.deepEqual(inventory(f.rootPath)[p], v, p);
  await f.command('serve', 2); await exactAdmin(f, 2, 'status', 'RUNNING');
  const upgrade = await f.command('upgrade'); assert.equal(upgrade.result.accepted.sequence, 2);
  assert.equal(upgrade.result.cellId, first.result.cellId);
  assert.notEqual(upgrade.result.accepted.release.profileDigest, first.result.accepted.release.profileDigest);
  for (const [p,v] of Object.entries(original)) if (p === 'identity.json' || p.startsWith('releases/') || p.startsWith('transactions/')) assert.deepEqual(inventory(f.rootPath)[p], v, p);
  await f.command('serve', 3); await exactAdmin(f, 1, 'status', 'RUNNING');
  const last = await f.command('maintain'); assert.deepEqual(last.result.accepted, upgrade.result.accepted);
  assert.equal(lstatSync(join(f.rootPath, 'supervision')).ino, fence);
  const retired = Object.entries(inventory(f.rootPath)).filter(([p]) => p.startsWith('supervision/retired-'));
  assert.equal(retired.length, 3); assert(retired.some(([,v]) => v.ino === original['supervision/incarnation.json'].ino && v.digest === original['supervision/incarnation.json'].digest));
  await f.command('finish'); await wait(() => f.child.exitCode !== null); assert.equal(f.child.exitCode, 0, f.errors()); excluded(f);
});
test('public cycle CLI restarts actual prior and target twice under continuous custody', { timeout: 60000 }, async t => {
  const f = await setup(t, 'none', 'cycle'); await wait(() => f.child.exitCode !== null || f.child.signalCode !== null, 50000);
  assert.equal(f.child.exitCode, 0, f.errors()); const rows = f.rows();
  assert.deepEqual(rows.filter(r => r.event === 'SERVING').map(r => r.accepted.sequence), [1,2,2]);
  assert.equal(rows.at(-1).status, 'STOPPED'); assert.equal(rows.at(-1).fence, 'RETAINED'); excluded(f);
});
function events(f) {
  return existsSync(join(f.dir, 'events.jsonl')) ? readFileSync(join(f.dir, 'events.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(JSON.parse) : [];
}
async function resume(f) {
  const p = spawn('python3', ['-c', 'import os,sys;f=os.open(sys.argv[1],os.O_WRONLY);os.close(f)', join(f.dir, 'pause.fifo')]);
  const [code] = await once(p, 'exit'); assert.equal(code, 0);
}
function immutablePreserved(f, before) {
  const after = inventory(f.rootPath);
  for (const [p,v] of Object.entries(before)) if (p === 'identity.json' || p === 'accepted.json' || p.startsWith('releases/') || p.startsWith('transactions/')) assert.deepEqual(after[p], v, p);
}
function changeAuthority(f, kind) {
  if (kind === 'revoked') {
    f.trust.revocation.version++;
    f.trust.revocation.revokedArtifactDigests.push(selection(f).release.bundleDigest);
  } else if (kind === 'equivocation') f.trust.revocation.expiresAtMs--;
  else if (kind === 'grants') f.authorization.capabilities[0].lifetimeMs--;
  f.trust.revocationSignature = signature(f.trust.revocation, 'ALICA-REVOCATION-v1', f.root);
  f.writeInput();
}
for (const boundary of ['maintenance', 'successor']) for (const kind of ['revoked', 'equivocation', 'grants'])
  test(`${boundary} rechecks current ${kind}; original accepted artifacts remain intact`, { timeout: 30000 }, async t => {
    const f = await setup(t, boundary === 'successor' ? 'pause-serve' : 'none');
    await f.event('begin'); const before = inventory(f.rootPath);
    if (boundary === 'successor') {
      f.child.stdin.write('serve\n'); await wait(() => events(f).some(e => e.event === 'paused-serve'));
      changeAuthority(f,kind); await resume(f);
    } else {
      await f.command('serve'); changeAuthority(f,kind); f.child.stdin.write('maintain\n');
    }
    await wait(() => f.child.signalCode !== null || f.errors().includes('NEEDS_OPERATOR'));
    assert.equal(f.rows().filter(r => r.event === (boundary === 'successor' ? 'serve' : 'maintain')).length, 0);
    immutablePreserved(f,before); excluded(f);
  });
for (const kind of ['bad-target-grants', 'bad-target-readiness', 'bad-target-call'])
  test('repeated maintenance real target denies ' + kind, { timeout: 30000 }, async t => {
    const f = await setup(t,kind); await f.event('begin'); const before = inventory(f.rootPath);
    await f.command('serve'); f.child.stdin.write('upgrade\n'); await wait(() => f.errors().includes('NEEDS_OPERATOR'));
    assert.equal(f.rows().filter(r=>r.event==='upgrade').length,0); immutablePreserved(f,before); excluded(f);
    const states = readdirSync(join(f.rootPath,'transactions')).map(p => {
      const dir=join(f.rootPath,'transactions',p); return JSON.parse(readFileSync(join(dir,readdirSync(dir).sort().at(-1)))).record.state;
    });
    assert(states.includes(kind === 'bad-target-grants' ? 'STAGING' : 'ABORTED'));
  });
for (const mode of ['forged-selection','kill-owner','kill-coordinator','crash-before-serve','crash-after-serve','forged-clean','crash-after-clean'])
  test('continuous custody fails closed at '+mode, {timeout:30000}, async t => {
    const f=await setup(t,mode); await f.event('begin'); const before=inventory(f.rootPath);
    f.child.stdin.write('serve\n');
    if (['forged-clean','crash-after-clean'].includes(mode)) { await f.event('serve'); f.child.stdin.write('maintain\n'); }
    await wait(()=> f.child.signalCode!==null || f.errors().includes('NEEDS_OPERATOR'));
    assert.equal(f.rows().filter(r=>r.event==='maintain').length,0); immutablePreserved(f,before); excluded(f);
    const replay=spawnSync(process.execPath,['--experimental-vm-modules','tools/g7-owned-cli.mjs','serve',f.rootPath,f.input],{encoding:'utf8',timeout:5000});
    assert.equal(replay.status,1); assert.deepEqual(JSON.parse(replay.stderr),{status:'NEEDS_OPERATOR',fence:'RETAINED'});
    for(const custody of [{clean:true},{receipt:f.rows()[0]},{pid:f.child.pid},{stopped:{status:'STOPPED'}}]) assert.throws(()=>new CellPreparation(f.rootPath,custody));
  });
for(const mode of ['crash-before-accepted','crash-after-accepted','uncertain-rename','uncertain-fsync','crash-after-commit'])
  test('repeated upgrade uncertain commit retains original history: '+mode,{timeout:30000},async t=>{
    const f=await setup(t,mode); await f.event('begin'); const before=inventory(f.rootPath), original=selection(f);
    await f.command('serve'); f.child.stdin.write('upgrade\n'); await wait(()=>f.child.signalCode!==null||f.errors().includes('NEEDS_OPERATOR'));
    assert.equal(f.rows().filter(r=>r.event==='upgrade').length,0); excluded(f);
    const after=inventory(f.rootPath);
    for(const [p,v] of Object.entries(before)) if(p==='identity.json'||p.startsWith('releases/')||p.startsWith('transactions/')) assert.deepEqual(after[p],v,p);
    assert.equal(selection(f).sequence,mode==='crash-before-accepted'?1:2);
    if(mode==='crash-before-accepted') assert.deepEqual(selection(f),original);
    const tx=readdirSync(join(f.rootPath,'transactions')).filter(p=>p!==original.transactionId); assert.equal(tx.length,1);
    const dir=join(f.rootPath,'transactions',tx[0]);
    const published=readdirSync(dir).filter(p=>/^\d{6}\.json$/.test(p)).sort();
    assert.equal(JSON.parse(readFileSync(join(dir,published.at(-1)))).record.state,mode==='crash-after-commit'?'COMMITTED':'ACTIVATING');
    if(mode==='crash-after-commit') assert(readdirSync(dir).some(p=>p.startsWith('next-')));
  });
for(const mode of ['block-activation','block-cleanup','block-normal-exit','late-clean','block-maintenance'])
  test('independent unchanged watchdog contains actual repeated '+mode,{timeout:mode==='block-maintenance'?340000:65000},async t=>{
    const f=await setup(t,mode); await f.event('begin'); const before=inventory(f.rootPath);
    const start=performance.now(); f.child.stdin.write('serve\n');
    if(mode!=='block-activation') { await f.event('serve'); f.child.stdin.write('maintain\n'); }
    await wait(()=>f.child.signalCode!==null,mode==='block-maintenance'?325000:50000);
    assert.equal(f.child.signalCode,'SIGKILL'); assert(performance.now()-start >= (mode==='block-maintenance'?299000:29000));
    assert.equal(f.rows().filter(r=>r.event==='maintain').length,0); immutablePreserved(f,before); excluded(f);
  });

