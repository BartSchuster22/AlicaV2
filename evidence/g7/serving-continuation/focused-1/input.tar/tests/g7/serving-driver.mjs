// Test harness drives only real public orchestration; no supplied clean authority.
import { createInterface } from 'node:readline';
import { CellPreparation } from '../../tools/g7-cell.mjs';
import { createRequire } from 'node:module';
const native = createRequire(import.meta.url)('../../native/g7/build/ownership.node');
native.guardLauncher();
const [root, input, target] = process.argv.slice(2);
const cell = new CellPreparation(root);
const commands = createInterface({ input: process.stdin });
const timer = setInterval(() => {}, 1000);
let current = input;
try {
  console.log(JSON.stringify({ event: 'begin', result: await cell.ownedBegin(input) }));
  for await (const command of commands) {
    let result;
    if (command === 'serve') result = await cell.ownedServe(current);
    else if (command === 'maintain') result = await cell.ownedMaintain(current);
    else if (command === 'upgrade') {
      result = await cell.ownedMaintain(current, target);
      current = target;
    } else if (command === 'concurrent') {
      const first = cell.ownedMaintain(current);
      try { await cell.ownedMaintain(current); throw new Error('concurrent admission'); }
      catch (e) { if (e.code !== 'CONFLICT') throw e; }
      result = await first;
    } else if (command === 'finish') {
      result = await cell.ownedFinish();
      cell.close();
      console.log(JSON.stringify({ event: command, result }));
      clearInterval(timer);
      commands.close();
      process.exit(0);
    } else throw new Error('unknown test command');
    console.log(JSON.stringify({ event: command, result }));
  }
  throw new Error('harness ended without finish');
} catch (error) {
  console.error(JSON.stringify({ status: 'NEEDS_OPERATOR', code: error.code, stack: error.stack }));
}
