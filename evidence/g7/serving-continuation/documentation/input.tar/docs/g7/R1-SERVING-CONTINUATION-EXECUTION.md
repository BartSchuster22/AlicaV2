# R1 serving continuation — development execution

Baseline: `974ee15e460e3a8bebabd9d7251d1fcd5f0c5028`.

Development root: `alica-dev@167.233.135.142:/home/alica-dev/AlicaV2`. Local handoff: `/home/herman/g7-implementation`. No commit, push, deployment, production signing/key access, dependency/global installation, RAM/swap change or protected licensing/archive modification. One source writer; no child agents/cron. Only disposable development Cells were exercised. Parent independently reviews, reruns and publishes.

## Evidence and execution order

All paths below are under `evidence/g7/serving-continuation/`. Each run retains its exact source allowlist, input hashes/archive, before/after source hashes, raw output, exit status and returned archive. New lifecycle tests additionally retain original disposable Cell files, original accepted archive, separate target archive/planning state, inputs, authenticated-channel observations and stopped-boundary inode/digest observations. Captured native/channel data is evidence, never a reusable clean certificate. Existing evidence, including restored original failure artifacts and their intentional whitespace, is not normalized or removed.

| Run | Actual result | Meaning |
| --- | --- | --- |
| `focused-1` | 2/2 pass | Original-Cell repeated maintenance/real target upgrade and public cycle CLI; native G7 build receipt in raw output. |
| `adversarial-1` | 20/21 pass | Found missing immediate foreground notification when coordinator dies after SERVING. Original failed run retained. |
| `correction-and-boundaries` | 12/12 pass | Loss notification correction, seven filesystem fence death boundaries, shared-eight admission, continuous flock competition and foreground graceful stop. |
| `focused-final-candidate` | 338/340 pass; 9 nested Python channel/reap tests pass | Two new harness defects: inventory attempted during legitimate live Kernel rename (`g7-serve-uPe7hL`), and wrong one-second test expectation for CLEAN ACK inside existing 30-second cleanup budget. Production deadlines unchanged. |
| `final-corrections` | 3/3 pass | Corrected stopped-only inventory and original cleanup-budget assertion; real pidfd-pinned runtime child death produces actual public-Kernel FAILED and cannot certify serving. |
| `focused-final` | 341/341 pass; 9 nested Python channel/reap tests pass | Final all-G7 source-bound focused run; no cancellations, skips or todos. |
| `full-check` | Exit 0, all stages pass | Full `npm run check`, started strictly after successful focused run; unchanged executable source. Node suites: 170 foundation/Kernel/SDK, 162 G6 native, 341 G7. Python suites: 193 schemas, 30 G6 design, 11 G7 bootstrap, 9 nested custody, 121 G7 contracts. |

The coordinator-loss fix invalidates the lexical session on the exact spawned child's exit and exposes `ownedWait()` so the foreground CLI is notified while idle. It does not interpret that exit as clean. A separate review correction requires real RUNNING, not merely any authenticated snapshot, before the private READY receipt. Its test kills an actual successor runtime child through a held pidfd, waits for real public-Kernel FAILED, and leaves the original accepted artifacts untouched. Neither correction changes the live admin protocol or stop contract.

The harness inventory correction removes an unnecessary serving-time full inventory capture, not the stopped no-op assertions. Whole-file byte/inode comparisons still run at each actual CLEAN-to-maintenance boundary, including opaque Kernel state. Immutable accepted artifacts are checked by exact original paths even when the live Kernel can legitimately write its own temporary state. No filesystem errors are swallowed to manufacture an equal snapshot.

## Coverage in the new real-process suite

- Same original root, identity, accepted revision and original release/journal bytes; exact initial reinstall, serving, v1/v2 admin stop/start, concurrent orchestration rejection, exact maintenance, distinct actual prior-to-target upgrade, repeated target serving and maintenance, and normal final coordinator reap.
- Exact v1/v2 request/response binding; separate endpoint/version rejection; stale incarnation rejection; explicit EOF admission; seven unsealed requests plus status, aggregate eight admitted requests and rejected ninth; private seal closes admitted unsealed mutations without dispatch.
- Original supervision directory inode retained; original incarnation inode/bytes archived; every predecessor normally reaped before successor endpoint rebinding. Continuous independent flock competitor probes across serving, upgrade and repeated reaps.
- Independent current revoked/equivocating trust and changed authorization at maintenance and AGAIN after parent preflight but before successor admission. Actual target grant failure, actual missing readiness and wrong synthetic result. Actual runtime child death before serving readiness.
- Owner, coordinator and foreground parent deaths; forged selection, forged CLEAN binding, stale/fabricated custody objects and new invocation replay rejected. Lost custody is never automatically adopted.
- Actual process death around retirement hardlink, directory fsync, old incarnation/socket retirement and new incarnation fsync. Original fence and original accepted history remain, including interrupted publication residues.
- Actual accepted rename, directory sync and COMMITTED link death/uncertain syscall boundaries. Prior immutable history remains; pointer/journal residue is not automatically repaired, rolled back or replayed.
- Real blocking FIFO IO at successor activation, cleanup, and after clean report but before normal exit; delayed authenticated CLEAN receipt; blocked original maintenance parent. Actual independent containment uses unchanged 30000 ms activation/cleanup and 300000 ms verification budgets. Deadline observations use monotonic event timestamps. The ACK remains within its original cleanup budget, not a new timer.

The focused/full suites also rerun earlier A1+B1 framing/unknown-selection/cap/deadline tests, native credential/pidfd/normal-reap tests, prior stopped verification, cross-process exact reinstall/upgrade, actual accepted restart and existing Cell/trust lifecycle tests without weakening them.

## Safety boundaries and remaining work

See `R1-SERVING-CONTINUATION-CHECKPOINT.md` for the API and exact custody/deadline model. Serving is continuously owned from inception; no arbitrary previously fenced Cell can enter. Ordinary admin stop still means restartable stopped custody under that existing custodian. Returning to offline maintenance instead requires private sealing and fresh actual owner/custodian normal reaps. The original flock is never unlocked/replaced between phases.

Crash cases here demonstrate conservative containment, original preservation and denial—not successful general post-crash recovery. Losing the foreground owner loses the continuous certificate. Parent-death kill, pidfd readability, accepted pointer/COMMITTED bytes, socket absence or a copied receipt do not prove normal cleanup. R1 approved recovery requirements still apply. No new owner exception is invented; safe general detached post-crash reconciliation remains an implementation/qualification gap. No automatic rollback/replay or revival of revoked prior is implemented.

These are SIGKILL and injected real-syscall boundaries, not power-loss/storage qualification. Development fixtures and distinct target lock planning are not an assembled release/SBOM delivery or two-host qualification. The real restart uses the original Cell's opaque Kernel state, never the separate target planning state. The original grant lifetime limits are unchanged; indefinite orchestration is not automatic grant/trust renewal.

Still required for G7: actual assembly/SBOM/provenance/license/bootstrap qualification using prior inventory preparation as input, encrypted stopped backup and independent same-identity restore, online/disconnected two-host qualification of identical actual assembled bytes, owner signing and final acceptance. This checkpoint is not G7 completion.

Final preservation/source-binding/native-receipt/process verification is recorded in `verification/summary.json` and its adjacent originals. It checks every initial local and remote inventory entry: no removals and only the five allowlisted runtime source changes; final executable source equals both final runs' before/after hashes. Local/remote final source and documentation match. Final G6/G7 native receipts are preserved verbatim. Documentation was finalized/formatted separately after executable checks; no executable source changed afterward. No commits or pushes were made, and both HEADs remain at the baseline.
