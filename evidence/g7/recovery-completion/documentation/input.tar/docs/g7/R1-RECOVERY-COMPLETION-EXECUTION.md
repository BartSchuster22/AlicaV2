# R1 recovery completion — development execution record

Status: unpublished component handoff, NOT gate acceptance. Parent independently reviews/reruns/publishes. Source baseline `a314e56a17958fa7befa0d07b90b8327c8e2fd0c` remains the HEAD; no commit or push.

## Custody and preserved inputs

Local root `/home/herman/g7-implementation`; disposable development host `alica-dev@167.233.135.142:/home/alica-dev/AlicaV2`. SSH used the specified identity-only/batch/strict-host-key settings and pinned known-hosts file. Remote commands use project-local `.tools/node/bin` first in PATH. No production deployment, service operation, signing/key access, new dependency/global install, RAM/swap or protected licensing/archive modification. One source writer, no child agents/cron.

The earlier owner-approved capture-helper SCP had already completed. It was not repeated or reapproved. SHA256 was independently supplied by the parent and verified again against the helper: `5d341b413085d5ec0dc3f8a5dcb5774af9cc45038bcdc8cb454c8749cf527249`.

The partial local baseline `/home/herman/g7-recovery-local-baseline` was reused, not recreated. Its 31,002 inventoried entries were checked against the unchanged local worktree before implementation. Both HEADs matched the published baseline and no competing development test/worker was found. Remote baseline `/home/alica-dev/g7-recovery-remote-baseline` was captured only after an existence guard established absence; 32,571 entries include preexisting untracked G6/admin evidence. Those are historical inputs, not transfer targets.

Original `/home/herman/g7-recovery-completion-run.log` is preserved, not appended/replaced: 2,693 bytes, SHA256 `4a706c8b28342c9513c74d00fec590c38b6767e0e34c6f49c6e9ec4253683e6e`. All old evidence and intentional raw whitespace remain untouched. The old bundle-inventory preparation was read without modification and is not current release/SBOM evidence.

## Runs and raw artifacts

Evidence root: `evidence/g7/recovery-completion/`. Each run directory contains the exact outbound source allowlist and tar, local before/after hashes, remote command, timestamps/exit status, and a returned tar plus its separately extracted original remote run directory. Remote run bytes live locally under `<run>/returned/evidence/g7/recovery-completion/<run>/`. This nesting is intentional: local transport receipts never overwrite remote raw evidence.

The explicit recovery scenarios retain actual original prior and separate target archives, actual Cell files/journal history and stopped inventories. The broader runs enable existing serving/cross-process/owned-custody/admin/lifecycle evidence collectors, retaining real crash residues and normal/abnormal process observations. Native build receipts appear in raw output and are also collected at final verification. No generated error text is substituted for a failed run.

| Run | Result | Interpretation |
| --- | --- | --- |
| `focused-1` | 7/7 new recovery tests pass; command exit 0 | Formatter reported three warnings. The initial command used `;` before build/tests, so this is NOT a formatting pass. Raw warnings remain in `run.log`. |
| `focused-2` | 15/15 pass; exit 0 | Remote pinned Prettier formatting, native build, two successful recovery cases, seven refusal cases, six actual dependency-subassembly tests. Formatted executable source was copied back verbatim in `formatted-source.tar`; no package installation was attempted locally. |
| `final-focused` | 198/198 pass; 9 nested native custody Python tests pass; exit 0 | Broad real-process regression, including actual process/crash/rename/fsync failures and unchanged 30 s/300 s blocked-IO deadlines. Runtime source is unchanged afterward; a subsequent test-only amendment adds direct no-mutation-replay coverage and whole-inventory assertions for refusals. |
| `final-focused-corrected` | 16/16 pass; formatting and native build pass; exit 0 | Final executable and test source: two successful explicit recovery cases, eight refusal cases including no-mutation-replay, and six materialization/execution/negative subassembly tests. No skips/cancellations/todos. |
| `full-check` | `npm run check` exit 0 | Final source: 170 foundation/Kernel/SDK Node tests, 193 schema Python tests, 162 native G6 Node tests, 30 G6 protocol-model tests, 357 G7 Node tests, 121 G7 contract tests, and nested G7 Python suites of 11 and 9 tests. All pass; no G7 skips/cancellations/todos. Toolchain, dependency, boundary, secret, formatting, design, typecheck, external-consumer and native-build stages pass. |
| `subassembly-cli` | exit 0 | Executed the actual CLI entry point on the same final module, yielding 5 packages / 537 files. Raw bytes and dependency inventory retained separately from test artifacts. |

A local formatting attempt found no local Prettier module (`MODULE_NOT_FOUND`). This was an environment limitation, not a test pass. Formatting was performed with the already provisioned pinned remote tool, then its exact source bytes were synchronized locally. The initial warning-bearing run was not overwritten.

Final preservation/source/native binding results are recorded separately in `evidence/g7/recovery-completion/verification/summary.json`. That summary is emitted only after checking every baseline entry (no removed entries and only the three authorized existing source/test files changed), local/remote final source/document hashes, final focused/full source bindings, actual native files against their build receipts, the original worker-log digest, every remote evidence file against its returned local copy, and CLI subassembly bytes/inventory against the full-check artifact. Partial verification receipts are preserved on failure; their existence alone is not a verification pass. The verification directory also retains before/after inventories, Git diffs/status, final process observations, native artifacts/receipts and the exact capture/run/verification helpers.

The exercised dependency subassembly contains **5 packages, 537 files, 1,292,990 raw payload bytes**: AJV 8.20.0, fast-deep-equal 3.1.3, fast-uri 3.1.8, json-schema-traverse 1.0.0 and require-from-string 2.0.2. Four manifests declare MIT; fast-uri declares BSD-3-Clause. Actual license text files are included, not just those identifiers. Source package-lock SHA256: `e113136de6dabb322cb3fec5273abcfb54b36a12826a3e5c7061bb8a7a21c9bd`. The complete new staged inventory and isolated execution output are under each run that exercised subassembly tests in its `dependencies/` evidence directory.

## Reproduction and review

See `R1-RECOVERY-COMPLETION.md` for the precise R1 condition-to-test matrix, custody limitation, and assembly scope. The new API is stopped owned-maintenance engineering functionality, not a new v1/v2 live admin operation. General lost-custody cases remain fenced; successful activation-error recovery must not be described as successful detached crash recovery.

The CLI was exercised as `node tools/g7-runtime-dependencies.mjs . "$G7_DEPENDENCY_EVIDENCE"` with a new destination, using the project-local pinned Node. Its retained usable dependency tree and inventory are at `evidence/g7/recovery-completion/subassembly-cli/returned/evidence/g7/recovery-completion/subassembly-cli/dependencies/` locally. This tree is dependency-only, not a complete bootable Cell.

The full `npm run check` exercised final executable source and rebuilt native artifacts, without changing historical contracts/tests/deadlines. All old G1–G6 checks and G7 admin/serving tests remain mandatory. No gate, acceptance matrix row or parent-review document is marked accepted by this worker.
