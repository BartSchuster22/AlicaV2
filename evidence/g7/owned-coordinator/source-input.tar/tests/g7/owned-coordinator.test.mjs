import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, readdirSync, lstatSync, existsSync, rmSync, cpSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { once } from 'node:events';
import { setTimeout as delay } from 'node:timers/promises';
import { connect } from 'node:net';
import { canonical, rawDigest } from '@alica/acap-contracts';
import { CellPreparation } from '../../tools/g7-cell.mjs';
import { cellFixture } from './cell-fixture.mjs';

async function waitFor(fn, ms = 20000) {
  const end = performance.now() + ms;
  while (performance.now() < end) { const v = fn(); if (v) return v; await delay(20); }
  throw new Error('condition timed out');
}
function snapshot(root) {
  return Object.fromEntries(readdirSync(root, {recursive: true}).sort().flatMap(p => {
    const s = lstatSync(join(root,p));
    return s.isFile() ? [[p, {sha256: rawDigest(readFileSync(join(root,p))), ino: s.ino, mode: s.mode, mtimeMs: s.mtimeMs}]] : [];
  }));
}
async function setup(t, mode = 'none', env = {}) {
  const dir = mkdtempSync(join(tmpdir(), 'g7-owned-')), f = await cellFixture(dir), root = join(dir,'cell');
  mkdirSync(root, {mode: 0o700});
  const cell = new CellPreparation(root); await cell.initialize(f.trust, f.floor); cell.close();
  const input = join(dir, 'input.json');
  writeFileSync(input, canonical({archive:f.archive,trust:f.trust,authorization:f.authorization}), {mode:0o600});
  assert.equal(spawnSync('mkfifo',[join(dir,'pause.fifo')]).status,0);
  const child = spawn('python3',['tests/g7/owned-coordinator-driver.py',mode,dir,process.execPath,root,input], {detached:true, stdio:['ignore','pipe','pipe'],env:{...process.env,...env}});
  let output = '', errors = '';
  child.stdout.on('data', b => { output += b; }); child.stderr.on('data', b => { errors += b; });
  t.after(async () => {
    try { process.kill(-child.pid,'SIGKILL'); } catch(e) { if(e.code !== 'ESRCH') throw e; }
    if(child.exitCode === null && child.signalCode === null) await once(child,'exit');
    if(process.env.G7_OWNED_EVIDENCE) {
      const target = join(process.env.G7_OWNED_EVIDENCE,dir.split('/').at(-1)); mkdirSync(target,{recursive:true});
      writeFileSync(join(target,'stdout.log'),output); writeFileSync(join(target,'stderr.log'),errors);
      for(const name of ['events.jsonl','boundary.json','input.json']) if(existsSync(join(dir,name))) cpSync(join(dir,name),join(target,name));
      // Preserve actual original test artifacts and Cell bytes, but no live sockets/FIFOs.
      for(const p of readdirSync(dir,{recursive:true})) {
        if(lstatSync(join(dir,p)).isFile()) { const dest=join(target,'originals',p); mkdirSync(resolve(dest,'..'),{recursive:true}); cpSync(join(dir,p),dest); }
      }
    }
    rmSync(dir,{recursive:true,force:true});
  });
  return {...f,dir,root,input,child,output:()=>output,errors:()=>errors};
}
async function paused(f) { return waitFor(()=>existsSync(join(f.dir,'boundary.json')) && JSON.parse(readFileSync(join(f.dir,'boundary.json')))); }
function resume(f) { const p=spawn('python3',['-c','import os,sys; f=os.open(sys.argv[1],os.O_WRONLY); os.write(f,b"x"); os.close(f)',join(f.dir,'pause.fifo')]); return once(p,'exit'); }
function excluded(f) { assert.throws(()=>new CellPreparation(f.root)); }
function events(f) { return readFileSync(join(f.dir,'events.jsonl'),'utf8').trim().split('\n').map(JSON.parse); }
async function result(f) { await waitFor(()=>f.child.exitCode !== null || f.child.signalCode !== null); assert.equal(f.child.exitCode,0,f.errors()); return JSON.parse(f.output()); }
function admin(f, version, operation) {
  return new Promise(resolvePromise=>{
    const socket=connect(join(f.root,'supervision',version===1?'admin.sock':'admin-v2.sock'));
    let response=''; socket.on('error',()=>resolvePromise(null)); socket.on('data',b=>{response+=b.toString('hex');}); socket.on('close',()=>resolvePromise(response));
    socket.on('connect',()=>{ const incarnation=JSON.parse(readFileSync(join(f.root,'supervision/incarnation.json'))).incarnation; const data=Buffer.from(JSON.stringify({schemaVersion:`alica.cell-admin-request/v${version}`,requestId:'race',incarnation,expectedSequence:1,operation}));const header=Buffer.alloc(4);header.writeUInt32BE(data.length);socket.end(Buffer.concat([header,data])); });
  });
}

test('owned coordinator: independent custodian and owner normal reaps precede real stopped verification; original Cell preserved', {timeout:30000}, async t=>{
  const f=await setup(t,'before-maintenance'); await paused(f); excluded(f);
  const before=snapshot(f.root); const e=events(f);
  assert(e.some(v=>v.event==='after-CLEAN' && v.pid!==f.child.pid));
  assert.equal(e.filter(v=>v.event==='normal-reap').length,1);
  assert.equal(e.find(v=>v.event==='normal-reap').child,e.find(v=>v.event==='after-CLEAN').pid);
  await resume(f); const r=await result(f);
  assert.equal(r.operation,'verify-stopped'); assert.equal(r.status,'STOPPED'); assert.equal(r.fence,'RETAINED');
  assert.deepEqual(snapshot(f.root),before);
  assert.equal(events(f).filter(v=>v.event==='normal-reap').length,2);
  excluded(f); // Successful operation does not turn durable residue into takeover authority.
});

for(const boundary of ['before-fsync','after-fsync','before-READY','after-READY','before-SEALED','after-SEALED','before-CLEAN','after-CLEAN','after-reap','before-maintenance','after-maintenance']) {
  test('owned coordinator loss retains fence at '+boundary,{timeout:30000},async t=>{
    const f=await setup(t,boundary); const p=await paused(f); excluded(f);
    const before=snapshot(f.root); process.kill(f.child.pid,'SIGKILL'); await once(f.child,'exit');
    await delay(100); excluded(f); assert.deepEqual(snapshot(f.root),before);
    assert(!f.output().includes('"operation": "verify-stopped"'));
    assert(existsSync(join(f.root,'supervision')));
    if(p.pid!==f.child.pid) {
      // /proc is diagnostic only, never used by the production gate.
      const status=existsSync(`/proc/${p.pid}/stat`) ? readFileSync(`/proc/${p.pid}/stat`,'utf8') : '';
      assert(!status || status.split(') ')[1].startsWith('Z'));
    }
  });
}

for(const boundary of ['before-READY','before-SEALED','after-SEALED','before-CLEAN','after-CLEAN']) {
  test('custodian abnormal death cannot become stopped permission at '+boundary,{timeout:30000},async t=>{
    const f=await setup(t,boundary);const p=await paused(f);assert.notEqual(p.pid,f.child.pid);process.kill(p.pid,'SIGKILL');
    await waitFor(()=>f.output().includes('NEEDS_OPERATOR'));excluded(f);
    assert(!events(f).some(v=>v.event==='before-maintenance'));
  });
}

test('sealing excludes concurrent v1/v2 starts stops and mutations without a successor', {timeout:30000},async t=>{
  const f=await setup(t,'after-SEALED');await paused(f);
  const before=snapshot(f.root);
  const replies=await Promise.all([1,2].flatMap(v=>['start','stop','verify','status','upgrade'].map(op=>admin(f,v,op))));
  assert(replies.every(v=>v===null || v==='')); excluded(f);assert.deepEqual(snapshot(f.root),before);
  await resume(f);assert.equal((await result(f)).status,'STOPPED');
});

test('stopped verification uses original retained artifacts and current independent input, rejects tamper without Cell writes', {timeout:30000},async t=>{
  const f=await setup(t,'before-maintenance');await paused(f);
  const retained=join(f.root,'releases',readdirSync(join(f.root,'releases'))[0],'docs/fixture.txt');writeFileSync(retained,'corrupt');
  const before=snapshot(f.root);await resume(f);await waitFor(()=>f.output().includes('NEEDS_OPERATOR'));
  assert.deepEqual(snapshot(f.root),before);excluded(f);
});

test('late sealed receipt after actual unchanged cleanup budget cannot publish maintenance', {timeout:45000},async t=>{
  const f=await setup(t,'before-SEALED');await paused(f);
  await waitFor(()=>f.output().includes('NEEDS_OPERATOR'),35000);
  assert(!events(f).some(v=>v.event==='before-maintenance'));excluded(f);
});
