"""Real Unix process/credential/pidfd negative qualification."""
import importlib.util
import os
from pathlib import Path
import signal
import socket
import time
import unittest

spec = importlib.util.spec_from_file_location('owned', Path(__file__).resolve().parents[2] / 'tools/g7-owned-coordinator.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class Channels(unittest.TestCase):
    def test_real_child_credentials_and_held_pidfd_normal_reap(self):
        parent, child = m.pair()
        pid = os.fork()
        if pid == 0:
            parent.close()
            m.send(child, b'CHILD')
            os._exit(0)
        child.close()
        pidfd = os.pidfd_open(pid)
        try:
            self.assertEqual(m.until(parent, pid, pidfd, time.monotonic() + 2), b'CHILD')
            m.normal_reap(pid, pidfd, time.monotonic() + 2)
            with self.assertRaises(ChildProcessError):
                m.normal_reap(pid, pidfd, time.monotonic() + 2)
        finally:
            os.close(pidfd)
            parent.close()

    def test_socketpair_creator_is_not_actual_child_credential(self):
        a, b = m.pair()
        pid = os.fork()
        if pid == 0:
            os._exit(0)
        pidfd = os.pidfd_open(pid)
        try:
            # Even with both genuine inherited endpoints, a same-UID parent
            # writing a forged child receipt has its OWN actual SCM credentials.
            m.send(b, b'CLEAN {}')
            with self.assertRaisesRegex(RuntimeError, 'unowned sender'):
                m.receive(a, pid)
        finally:
            os.waitpid(pid, 0)
            os.close(pidfd)
            a.close()
            b.close()

    def test_plain_inherited_stream_fd_and_closed_channel_are_not_credentials(self):
        a, b = socket.socketpair()
        b.sendall(b'CLEAN {}')
        with self.assertRaises(RuntimeError):
            m.receive(a, os.getpid())
        b.close()
        with self.assertRaises(RuntimeError):
            m.receive(a, os.getpid())
        a.close()

    def test_forced_child_exit_is_never_normal_reap(self):
        pid = os.fork()
        if pid == 0:
            signal.pause()
            os._exit(0)
        pidfd = os.pidfd_open(pid)
        signal.pidfd_send_signal(pidfd, signal.SIGKILL)
        try:
            with self.assertRaisesRegex(RuntimeError, 'not a normal'):
                m.normal_reap(pid, pidfd, time.monotonic() + 2)
        finally:
            os.close(pidfd)

    def test_late_real_normal_exit_is_not_a_reap_permit(self):
        pid = os.fork()
        if pid == 0:
            os._exit(0)
        pidfd = os.pidfd_open(pid)
        try:
            with self.assertRaises(TimeoutError):
                m.normal_reap(pid, pidfd, time.monotonic() - 1)
        finally:
            os.waitpid(pid, 0)
            os.close(pidfd)

    def test_non_parent_guard_is_rejected(self):
        with self.assertRaises(RuntimeError):
            m.guard_parent(os.getpid())


if __name__ == '__main__':
    unittest.main()
